//
// This is dummy source file.
// All handlers for 7-th page are in Page06NtFileInfo.cpp
//

#include "FileTest.h"
#include "resource.h"
